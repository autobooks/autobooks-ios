//
//  VTPNumericInputType.h
//  triPOSMobileSDK
//
//  Created by Eric Mattison on 7/18/18.
//  Copyright © 2018 Vantiv Inc. All rights reserved.
//

#ifndef VTPNumericInputType_h
#define VTPNumericInputType_h

typedef enum _NumericInputType
{
    VTPNumericInputTypeTip,
    VTPNumericInputTypeCashback,
    
}   VTPNumericInputType;

#endif /* VTPNumericInputType_h */
