///
/// \file VPDNull+ChoiceInput.h
///

#ifndef VPDNull_ChoiceInput_h
#define VPDNull_ChoiceInput_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VPDChoiceInput.h"
#import "VPDNull.h"

@interface VPDNull(ChoiceInput) <VPDChoiceInput>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDNull_ChoiceInput_h */
