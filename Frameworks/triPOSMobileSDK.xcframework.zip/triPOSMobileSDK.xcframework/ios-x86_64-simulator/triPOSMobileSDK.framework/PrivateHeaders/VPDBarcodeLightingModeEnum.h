///
/// \file VPDBarcodeLightingModeEnum.h
//  Configuration
//
//  Created by Chance Ulrich on 2/29/16.
//  Copyright © 2018 Worldpay, LLC. and/or its affiliates. All rights reserved.
//

#ifndef VPDBarcodeLightingModeEnum_h
#define VPDBarcodeLightingModeEnum_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

//TODO: TO UNDERSTAND WHY THIS DOES NOT WORK, BUT WORKS OTHER PLACES #import "VPDBarcodeLightingMode.h"
#import "VTCEnum.h"

@interface VPDBarcodeLightingModeEnum : NSObject <VTCEnum>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDBarcodeLightingModeEnum_h */
