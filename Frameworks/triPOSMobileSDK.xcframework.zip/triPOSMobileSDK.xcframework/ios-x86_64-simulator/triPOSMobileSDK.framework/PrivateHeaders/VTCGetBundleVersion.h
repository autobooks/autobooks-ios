///
/// \file VTCGetBundleVersion.h
///

#ifndef VTCGetBundleVersion_h
#define VTCGetBundleVersion_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

@interface VTCGetBundleVersion : NSObject

+(NSString *)version;

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VTCGetBundleVersion_h */
