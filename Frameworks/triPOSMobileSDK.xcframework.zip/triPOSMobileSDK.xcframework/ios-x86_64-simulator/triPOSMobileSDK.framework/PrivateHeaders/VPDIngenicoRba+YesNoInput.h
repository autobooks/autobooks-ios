///
/// \file VPDIngenicoRba+YesNoInput.h
///

#ifndef VPDIngenicoRba_YesNoInput_h
#define VPDIngenicoRba_YesNoInput_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VPDYesNoInput.h"
#import "VPDIngenicoRba.h"

@interface VPDIngenicoRba(YesNoInput) <VPDYesNoInput>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDIngenicoRba_YesNoInput_h */
