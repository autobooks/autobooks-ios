///
/// \file VPDIngenicoRba+PinInput.h
///

#ifndef VPDIngenicoRba_PinInput_h
#define VPDIngenicoRba_PinInput_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VPDPinInput.h"
#import "VPDIngenicoRba.h"

@interface VPDIngenicoRba(PinInput) <VPDPinInput>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDIngenicoRba_PinInput_h */
