///
/// \file VPDBarcodeTypeEnum.h
///

#ifndef VPDBarcodeTypeEnum_h
#define VPDBarcodeTypeEnum_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

//TODO: TO UNDERSTAND WHY THIS DOES NOT WORK, BUT WORKS OTHER PLACES #import "VPDBarcodeType.h"
#import "VTCEnum.h"

@interface VPDBarcodeTypeEnum : NSObject <VTCEnum>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDBarcodeTypeEnum_h */
