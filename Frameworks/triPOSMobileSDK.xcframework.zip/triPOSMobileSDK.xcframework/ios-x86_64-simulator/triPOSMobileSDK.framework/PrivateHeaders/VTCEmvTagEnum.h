///
/// \file VTCEmvTagEnum.h
///

#ifndef VTCEmvTagEnum_h
#define VTCEmvTagEnum_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VTCEmvTag.h"
#import "VTCEnum.h"

@interface VTCEmvTagEnum : NSObject <VTCEnum>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VTPPaymentTypeEnum_h */
