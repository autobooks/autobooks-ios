//
//  \file VTPWorldpayEmvFlow.h
//

#ifndef VTPWorldpayEmvFlow_h
#define VTPWorldpayEmvFlow_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VTPEmvFinalizeFlow.h"

@interface VTPWorldpayEmvFinalizeFlow : VTPEmvFinalizeFlow

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VTPWorldpayEmvFlow_h */
