///
/// \file VPDIngenicoRba+ChoiceInput.h
///

#ifndef VPDIngenicoRba_ChoiceInput_h
#define VPDIngenicoRba_ChoiceInput_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VPDChoiceInput.h"
#import "VPDIngenicoRba.h"

@interface VPDIngenicoRba(ChoiceInput) <VPDChoiceInput>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDIngenicoRba_ChoiceInput_h */
