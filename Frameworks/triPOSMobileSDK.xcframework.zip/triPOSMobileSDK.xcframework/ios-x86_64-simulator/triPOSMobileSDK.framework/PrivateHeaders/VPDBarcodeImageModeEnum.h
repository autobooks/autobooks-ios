///
/// \file VPDBarcodeImageModeEnum.h
//  Configuration
//
//  Created by Chance Ulrich on 2/29/16.
//  Copyright © 2018 Worldpay, LLC. and/or its affiliates. All rights reserved.
//

#ifndef VPDBarcodeImageModeEnum_h
#define VPDBarcodeImageModeEnum_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

//TODO: TO UNDERSTAND WHY THIS DOES NOT WORK, BUT WORKS OTHER PLACES #import "VPDBarcodeImageMode.h"
#import "VTCEnum.h"

@interface VPDBarcodeImageModeEnum : NSObject <VTCEnum>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDBarcodeImageModeEnum_h */
