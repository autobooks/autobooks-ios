//
//  VHTDeviceTokenHost+Null.h
//  triPOSMobileSDK
//

#import <Foundation/Foundation.h>

#import "VHTDeviceTokenHost.h"

@interface VHTDeviceTokenHostNull : VHTDeviceTokenHost <VHTDeviceTokenHost>

@end
