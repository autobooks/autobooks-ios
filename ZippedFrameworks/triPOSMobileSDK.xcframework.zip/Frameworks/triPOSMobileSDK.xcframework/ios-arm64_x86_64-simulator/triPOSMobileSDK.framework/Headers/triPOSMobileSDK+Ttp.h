
#define TRIPOS_TTP_SDK 1

#ifndef triPOSMobileSDK_Ttp_h
#define triPOSMobileSDK_Ttp_h

#endif /* triPOSMobileSDK_Ttp_h */
