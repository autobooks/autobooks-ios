//
//  VPDSignatureRequired.h
//  triPOSMobileSDK
//
//  Created on 3/30/20.
//  Copyright © 2020 Vantiv Inc. All rights reserved.
//

#ifndef VPDSignatureRequired_h
#define VPDSignatureRequired_h


typedef enum _VPDSignatureRequired
{
    VPDSignatureRequiredNotSet,
    VPDSignatureRequiredNo,
    VPDSignatureRequiredYes
    
}   VPDSignatureRequired;

#endif /* VPDSignatureRequired_h */
