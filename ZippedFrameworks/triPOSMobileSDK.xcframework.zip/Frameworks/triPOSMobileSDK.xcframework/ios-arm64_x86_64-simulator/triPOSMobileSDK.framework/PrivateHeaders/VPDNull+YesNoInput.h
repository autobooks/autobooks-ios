///
/// \file VPDNull+YesNoInput.h
///

#ifndef VPDNull_YesNoInput_h
#define VPDNull_YesNoInput_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VPDYesNoInput.h"
#import "VPDNull.h"

@interface VPDNull(YesNoInput) <VPDYesNoInput>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDNull_YesNoInput_h */
