///
/// \file VPDNull+KeyboardNumericInput.h
///

#ifndef VPDNull_KeyboardNumericInput_h
#define VPDNull_KeyboardNumericInput_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VPDKeyboardNumericInput.h"
#import "VPDNull.h"

@interface VPDNull(KeyboardNumericInput) <VPDKeyboardNumericInput>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDNull_KeyboardNumericInput_h */
