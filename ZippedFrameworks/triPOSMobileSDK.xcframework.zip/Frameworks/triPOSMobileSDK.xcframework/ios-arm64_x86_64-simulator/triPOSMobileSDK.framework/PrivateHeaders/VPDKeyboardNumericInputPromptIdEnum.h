///
/// \file VPDKeyboardNumericInputPromptIdEnum.h
///

#ifndef VPDKeyboardNumericInputPromptIdEnum_h
#define VPDKeyboardNumericInputPromptIdEnum_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

//TODO: TO UNDERSTAND WHY THIS DOES NOT WORK, BUT WORKS OTHER PLACES #import "VPDKeyboardNumericInputPromptId.h"
#import "VTCEnum.h"

@interface VPDKeyboardNumericInputPromptIdEnum : NSObject <VTCEnum>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDKeyboardNumericInputPromptIdEnum_h */
