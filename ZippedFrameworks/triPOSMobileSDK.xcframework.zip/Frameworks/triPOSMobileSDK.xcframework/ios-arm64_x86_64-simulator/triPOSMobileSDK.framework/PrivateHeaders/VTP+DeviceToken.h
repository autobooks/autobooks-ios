//
//  VTP+DeviceToken.h
//  triPOSMobileSDK
//

#ifndef VTP_DeviceToken_h
#define VTP_DeviceToken_h

#import "VTP.h"

@interface VTP(DeviceToken)

@end

#endif /* VTP_DeviceToken_h */
