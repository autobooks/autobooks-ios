///
/// \file VPDAppleTapToPay+CardInput.h
///

#ifndef VPDAppleTapToPay_CardInput_h
#define VPDAppleTapToPay_CardInput_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VPDCardInput.h"
#import "VPDAppleTapToPay.h"

@interface VPDAppleTapToPay(CardInput) <VPDCardInput>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VPDAppleTapToPay_CardInput_h */
