//
//  \file VTPWorldpayEmvFlow.h
//

#ifndef VTPWorldpayEmvFlow_h
#define VTPWorldpayEmvFlow_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VTPEmvFlow.h"

@interface VTPWorldpayEmvFlow : VTPEmvFlow

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VTPWorldpayEmvFlow_h */
