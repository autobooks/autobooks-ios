///
/// \file VTPAidPreferenceEnum.h
///

#ifndef VTPAidPreferenceEnum_h
#define VTPAidPreferenceEnum_h

#ifndef DOXYGEN_SHOULD_SKIP_THIS

#import "VTPAidPreference.h"
#import "VTCEnum.h"

@interface VTPAidPreferenceEnum : NSObject <VTCEnum>

@end

#endif /* !DOXYGEN_SHOULD_SKIP_THIS */

#endif /* VTPAidPreference_h */
