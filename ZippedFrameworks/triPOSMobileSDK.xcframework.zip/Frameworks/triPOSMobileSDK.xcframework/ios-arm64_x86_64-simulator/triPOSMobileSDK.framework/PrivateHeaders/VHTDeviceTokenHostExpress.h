//
//  VHTDeviceTokenHost+Express.h
//  triPOSMobileSDK
//

#import <Foundation/Foundation.h>

#import "VHTDeviceTokenHost.h"

@interface VHTDeviceTokenHostExpress : VHTDeviceTokenHost <VHTDeviceTokenHost>

@end
